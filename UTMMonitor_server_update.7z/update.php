<?php

class Updater {
	
	private function getLatestVersion()
	{
		$matches = array();
		$versions = array();
		
		foreach (glob(dirname(__FILE__).'/UTMMonitor*.zip') as $file) {
			if (preg_match('/UTMMonitor v(.+).zip/', $file, $matches) > 0) {
				$versions[] = $matches[1];
			}
		}
		rsort($versions);
		return $versions[0];
	}
	
	public function processRequest($request)
	{
		switch ($request) {
			case 'version':
				$latestVersion = $this->getLatestVersion();
				sendResponse(200, $latestVersion);
				break;
			case 'download':
				// не укаазана версия, которую нужно скачать
				if (!isset($_GET['version']))
					sendResponse(400);
				
				$version = $_GET['version'];
				$file = dirname(__FILE__)."/UTMMonitor v{$version}.zip";
				echo $file;
				if (file_exists($file)) {
					if (ob_get_level())
						ob_end_clean();
					header('Content-Description: File Transfer');
					header('Content-Type: application/octet-stream');
					header('Content-Disposition: attachment; filename=' . basename($file));
					header('Content-Transfer-Encoding: binary');
					header('Expires: 0');
					header('Cache-Control: must-revalidate');
					header('Pragma: public');
					header('Content-Length: ' . filesize($file));
					readfile($file);
					exit;
				}
				else
					sendResponse(404);
				break;
			default:
				sendResponse(400);
		}
	}
}

function getStatusCodeMessage($status)
{
	$codes = Array(
			200 => 'OK',
			400 => 'Bad Request',
			401 => 'Unauthorized',
			402 => 'Payment Required',
			403 => 'Forbidden',
			404 => 'Not Found',
			500 => 'Internal Server Error',
			501 => 'Not Implemented',
	);
	return (isset($codes[$status])) ? $codes[$status] : '';
}

function sendResponse($status = 200, $body = '', $contentType = 'text/html')
{
	$status_header = 'HTTP/1.1 '.$status.' '.getStatusCodeMessage($status);
	header($status_header);
	header('Content-type: ' . $contentType);
	
	if ($body != '') {
		echo $body;
	}
	else {
		$message = '';
		switch($status) {
			case 401:
				$message = 'You must be authorized to view thid page.';
				break;
			case 404:
				$message = 'The requested URL '.$_SERVER['REQUEST_URI'].' was not found.';
				break;
			case 500:
				$message = 'The server encountered an error processing your request.';
				break;
			case 501:
				$message = 'The requested method is not implemented.';
				break;
		}
		$signature = ($_SERVER['SERVER_SIGNATURE'] == '') ? $_SERVER['SERVER_SOFTWARE'] . ' Server at ' . $_SERVER['SERVER_NAME'] . ' Port ' . $_SERVER['SERVER_PORT'] : $_SERVER['SERVER_SIGNATURE'];
		$body = require(dirname(__FILE__).'/body.php');
	}
	exit;
}

if (!isset($_GET['action'])) {
	sendResponse(400);
}
else {
	$updater = new Updater();
	$updater->processRequest($_GET['action']);
}
